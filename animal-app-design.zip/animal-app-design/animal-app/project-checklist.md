* Project title: Animal App
* Description: - choose an animal, get articles and pics related to the animals from Wiki and Giphy

* Repository Configured: Yes

* User story: I want to find articles and pictures pertaining to my favorite animals. 
WHEN I visit the app I am presented with a drop down list of animals to choose from.
THEN I pick an animal and am presented with gifs and a Wiki article pertaining to my chosen animal. 
THEN I am able to save the gif and article to view later and I may also choose a different animal. 


* Wireframe or sketch of the design: Added to ./assets/images

* API's identified:

Wiki "http://en.wikipedia.org/w/api.php?origin=*&action=query&prop=extracts&exintro&explaintext&redirects=1&titles=Zebra&format=json"
 
 Giphy "http://api.giphy.com/v1/gifs/search?q=zebra&api_key=wrXSrUy02o5zN56E5cFhtNzijtmeWcKe&limit=1"



* Issues created and assigned: Yes
